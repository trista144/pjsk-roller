// 主页只需要把曲库规模填进页面，其余是纯静态内容。
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  function loadLibrary() {
    try {
      return JSON.parse(document.getElementById("libraryData").textContent);
    } catch {
      return null;
    }
  }

  function main() {
    const lib = loadLibrary();
    if (!lib) return;

    const songs = Array.isArray(lib.songs) ? lib.songs : [];
    const songCount = lib.meta && lib.meta.songCount ? lib.meta.songCount : songs.length;
    let chartCount = 0;
    for (const song of songs) {
      if (song.d) chartCount += Object.keys(song.d).length;
    }

    const date = (lib.meta && lib.meta.generatedAt) || "";

    const pairs = [
      ["heroSongCount", songCount],
      ["noteSongCount", songCount],
      ["heroChartCount", chartCount],
      ["noteChartCount", chartCount],
    ];
    for (const [id, value] of pairs) {
      const el = $(id);
      if (el) el.textContent = String(value);
    }
    for (const id of ["noteDate", "dataDate"]) {
      const el = $(id);
      if (el && date) el.textContent = date;
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }
})();
