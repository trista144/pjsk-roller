(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  /* ---------- 规格（来源：data/profile-spec.json，国服 6.4.0 实测） ---------- */
  const CANVAS_W = 1800;
  const CANVAS_H = 800;
  const CANVAS_RADIUS = 18;

  const PALETTE = [
    "#FFFFFF",
    "#33CCBB", "#FFCC11", "#4455DD", "#BBDD22", "#FFAACC", "#00BBDD", "#FFBB00", "#884499", "#DDAACC",
    "#444466", "#FFEE11", "#33AAEE", "#88DD44", "#99EEDD", "#FF7722", "#FF66BB", "#BB6688",
    "#FFBBCC", "#FFDD44", "#FFCCAA", "#EE1166", "#0077DD", "#33DD99", "#8888CC",
    "#3366CC", "#DD4444", "#EE6666", "#99CCFF", "#FF6699", "#FF9900", "#BB88EE", "#CCAA88",
  ];

  const PALETTE_RGB = PALETTE.map((hex) => [
    parseInt(hex.slice(1, 3), 16),
    parseInt(hex.slice(3, 5), 16),
    parseInt(hex.slice(5, 7), 16),
  ]);

  const state = {
    image: null,
    imageName: "",
    fit: "cover",
    grid: 6,
    guides: true,
    view: "mapped",
  };

  const els = {
    dropZone: $("dropZone"),
    fileInput: $("fileInput"),
    canvasWrap: $("canvasWrap"),
    canvas: $("preview"),
    actions: $("actions"),
    statusHint: $("statusHint"),
    paletteUsage: $("paletteUsage"),
    exportBtn: $("exportBtn"),
    resetBtn: $("resetBtn"),
    resetSettings: $("resetSettings"),
    viewMode: $("viewMode"),
    fitMode: $("fitMode"),
    gridMode: $("gridMode"),
    guidesToggle: $("guidesToggle"),
    canvasSize: $("canvasSize"),
  };

  const ctx = els.canvas.getContext("2d", { willReadFrequently: true });

  // 32 级 RGB 归并缓存：同一 (r,g,b) 只算一次最近色，避免逐像素做 33 次距离比较
  let colorCache = new Map();

  function nearestPaletteIndex(r, g, b) {
    const key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
    const cached = colorCache.get(key);
    if (cached !== undefined) return cached;
    let best = 0;
    let bestDist = Infinity;
    for (let i = 0; i < PALETTE_RGB.length; i += 1) {
      const [pr, pg, pb] = PALETTE_RGB[i];
      // 加权欧氏距离，更贴近人眼对绿色更敏感的特性
      const dr = r - pr;
      const dg = g - pg;
      const db = b - pb;
      const dist = 2 * dr * dr + 4 * dg * dg + 3 * db * db;
      if (dist < bestDist) {
        bestDist = dist;
        best = i;
      }
    }
    colorCache.set(key, best);
    return best;
  }

  /* ---------- 绘制 ---------- */
  function drawRoundedRect(context, x, y, w, h, r) {
    context.beginPath();
    context.moveTo(x + r, y);
    context.arcTo(x + w, y, x + w, y + h, r);
    context.arcTo(x + w, y + h, x, y + h, r);
    context.arcTo(x, y + h, x, y, r);
    context.arcTo(x, y, x + w, y, r);
    context.closePath();
  }

  function drawImageCover(context) {
    const img = state.image;
    if (!img) return;
    const scale =
      state.fit === "cover"
        ? Math.max(CANVAS_W / img.width, CANVAS_H / img.height)
        : Math.min(CANVAS_W / img.width, CANVAS_H / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    const x = (CANVAS_W - w) / 2;
    const y = (CANVAS_H - h) / 2;
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.drawImage(img, x, y, w, h);
  }

  let mappedByFit = new Map();

  function mappedImageData() {
    const cached = mappedByFit.get(state.fit);
    if (cached) return cached;
    const fresh = computeMapped();
    mappedByFit.set(state.fit, fresh);
    return fresh;
  }

  function computeMapped() {
    // 先离屏渲染原图，再逐像素映射到 33 色
    const off = document.createElement("canvas");
    off.width = CANVAS_W;
    off.height = CANVAS_H;
    const octx = off.getContext("2d", { willReadFrequently: true });
    octx.fillStyle = "#FFFFFF";
    octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    if (state.fit === "contain") drawImageCover(octx);
    else drawImageCover(octx);

    const data = octx.getImageData(0, 0, CANVAS_W, CANVAS_H);
    const px = data.data;
    const usage = new Array(PALETTE.length).fill(0);

    for (let i = 0; i < px.length; i += 4) {
      if (px[i + 3] < 128) {
        // 半透明处按白底处理
        px[i] = 255; px[i + 1] = 255; px[i + 2] = 255; px[i + 3] = 255;
      }
      const idx = nearestPaletteIndex(px[i], px[i + 1], px[i + 2]);
      const [r, g, b] = PALETTE_RGB[idx];
      px[i] = r; px[i + 1] = g; px[i + 2] = b; px[i + 3] = 255;
      usage[idx] += 1;
    }
    return { data, usage };
  }

  function drawGuides(context) {
    context.save();
    context.strokeStyle = "rgba(255, 90, 140, 0.55)";
    context.lineWidth = 1.5;
    context.setLineDash([8, 6]);
    // 中轴
    context.beginPath();
    context.moveTo(CANVAS_W / 2, 0);
    context.lineTo(CANVAS_W / 2, CANVAS_H);
    context.moveTo(0, CANVAS_H / 2);
    context.lineTo(CANVAS_W, CANVAS_H / 2);
    context.stroke();

    // 边缘吸附区（约占画布宽高的 3%）
    const m = 0.03;
    context.strokeStyle = "rgba(60, 170, 210, 0.55)";
    context.beginPath();
    context.moveTo(CANVAS_W * m, 0);
    context.lineTo(CANVAS_W * m, CANVAS_H);
    context.moveTo(CANVAS_W * (1 - m), 0);
    context.lineTo(CANVAS_W * (1 - m), CANVAS_H);
    context.moveTo(0, CANVAS_H * m);
    context.lineTo(CANVAS_W, CANVAS_H * m);
    context.moveTo(0, CANVAS_H * (1 - m));
    context.lineTo(CANVAS_W, CANVAS_H * (1 - m));
    context.stroke();
    context.restore();
  }

  function drawGrid(context) {
    const n = state.grid;
    if (!n) return;
    const stepX = CANVAS_W / n;
    const stepY = CANVAS_H / n;
    context.save();
    context.strokeStyle = "rgba(90, 110, 130, 0.28)";
    context.lineWidth = 1;
    context.beginPath();
    for (let i = 1; i < n; i += 1) {
      context.moveTo(i * stepX, 0);
      context.lineTo(i * stepX, CANVAS_H);
      context.moveTo(0, i * stepY);
      context.lineTo(CANVAS_W, i * stepY);
    }
    context.stroke();

    // 顶部/左侧百分比标注：白描边 + 深色字，深浅底图都能读
    context.font = "700 20px system-ui, sans-serif";
    context.lineWidth = 4;
    context.strokeStyle = "rgba(255, 255, 255, 0.92)";
    context.fillStyle = "rgba(40, 58, 76, 0.92)";
    context.textBaseline = "top";
    context.textAlign = "center";
    for (let i = 1; i < n; i += 1) {
      const pct = Math.round((i / n) * 100);
      const label = `${pct}%`;
      context.strokeText(label, i * stepX, 7);
      context.fillText(label, i * stepX, 7);
    }
    context.textAlign = "left";
    context.textBaseline = "middle";
    for (let i = 1; i < n; i += 1) {
      const pct = Math.round((i / n) * 100);
      const label = `${pct}%`;
      context.strokeText(label, 7, i * stepY);
      context.fillText(label, 7, i * stepY);
    }
    context.restore();
  }

  function render() {
    const img = state.image;
    if (!img) return;

    els.canvasWrap.hidden = false;
    els.actions.hidden = false;
    els.canvas.width = CANVAS_W;
    els.canvas.height = CANVAS_H;

    const mapped = mappedImageData();
    const original = document.createElement("canvas");
    original.width = CANVAS_W;
    original.height = CANVAS_H;
    const octx = original.getContext("2d");
    octx.fillStyle = "#FFFFFF";
    octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    drawImageCover(octx);

    ctx.save();
    drawRoundedRect(ctx, 0, 0, CANVAS_W, CANVAS_H, CANVAS_RADIUS);
    ctx.clip();
    if (state.view === "original") {
      ctx.drawImage(original, 0, 0);
    } else if (state.view === "split") {
      ctx.drawImage(mapped.canvas || drawMapped(mapped), 0, 0);
      ctx.drawImage(original, CANVAS_W / 2, 0, CANVAS_W / 2, CANVAS_H, CANVAS_W / 2, 0, CANVAS_W / 2, CANVAS_H);
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(CANVAS_W / 2, 0);
      ctx.lineTo(CANVAS_W / 2, CANVAS_H);
      ctx.stroke();
    } else {
      ctx.drawImage(drawMapped(mapped), 0, 0);
    }
    if (state.guides) drawGuides(ctx);
    if (state.grid) drawGrid(ctx);
    ctx.restore();

    renderPaletteUsage(mapped.usage);
  }

  let mappedCache = null;
  function drawMapped(mapped) {
    if (mappedCache && mappedCache.source === mapped.data) return mappedCache.canvas;
    const canvas = document.createElement("canvas");
    canvas.width = CANVAS_W;
    canvas.height = CANVAS_H;
    canvas.getContext("2d").putImageData(mapped.data, 0, 0);
    mappedCache = { source: mapped.data, canvas };
    return canvas;
  }

  function renderPaletteUsage(usage) {
    const total = usage.reduce((a, b) => a + b, 0) || 1;
    const rows = usage
      .map((count, index) => ({ index, count, pct: (count / total) * 100 }))
      .filter((row) => row.pct >= 0.15)
      .sort((a, b) => b.count - a.count)
      .slice(0, 12);

    if (!rows.length) return;
    els.paletteUsage.replaceChildren();
    for (const row of rows) {
      const line = document.createElement("div");
      line.className = "palette-row";
      const swatch = document.createElement("i");
      swatch.className = "palette-dot";
      swatch.style.background = PALETTE[row.index];
      const name = document.createElement("code");
      name.textContent = PALETTE[row.index];
      const bar = document.createElement("span");
      bar.className = "palette-bar";
      const fill = document.createElement("b");
      fill.style.width = `${Math.min(100, row.pct)}%`;
      fill.style.background = PALETTE[row.index];
      bar.append(fill);
      const num = document.createElement("em");
      num.textContent = `${row.pct.toFixed(1)}%`;
      line.append(swatch, name, bar, num);
      els.paletteUsage.append(line);
    }
    const note = document.createElement("p");
    note.className = "field-note";
    note.textContent = `共用到 ${usage.filter((c) => c > 0).length} 种颜色。占比越高越适合用大图形铺，占比低的零碎色块建议用文字拼。`;
    els.paletteUsage.append(note);
  }

  /* ---------- 文件读取 ---------- */
  function loadFile(file) {
    if (!file || !file.type.startsWith("image/")) {
      els.statusHint.textContent = "这个文件不是图片，换一个试试。";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        state.image = img;
        state.imageName = file.name || "image";
        mappedCache = null;
        mappedByFit = new Map();
        els.dropZone.hidden = true;
        els.statusHint.textContent =
          `已载入 ${file.name}（${img.width}×${img.height}）。网格数字是占画布宽高的百分比，摆元素时对着网格估位置即可。`;
        render();
      };
      img.onerror = () => {
        els.statusHint.textContent = "这张图读不出来，换一张试试。";
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  /* ---------- 事件 ---------- */
  function bindSeg(container, attr, onPick) {
    container.addEventListener("click", (event) => {
      const btn = event.target.closest("button");
      if (!btn || !container.contains(btn)) return;
      container.querySelectorAll("button").forEach((b) => b.classList.toggle("is-on", b === btn));
      onPick(btn.dataset[attr]);
    });
  }

  function bindEvents() {
    els.dropZone.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => {
      if (els.fileInput.files && els.fileInput.files[0]) loadFile(els.fileInput.files[0]);
    });

    ["dragenter", "dragover"].forEach((type) => {
      els.dropZone.addEventListener(type, (event) => {
        event.preventDefault();
        els.dropZone.classList.add("is-over");
      });
    });
    ["dragleave", "drop"].forEach((type) => {
      els.dropZone.addEventListener(type, (event) => {
        event.preventDefault();
        els.dropZone.classList.remove("is-over");
      });
    });
    els.dropZone.addEventListener("drop", (event) => {
      const file = event.dataTransfer?.files?.[0];
      if (file) loadFile(file);
    });

    // 直接 Ctrl+V 粘贴图片
    window.addEventListener("paste", (event) => {
      const items = event.clipboardData?.items || [];
      for (const item of items) {
        if (item.type.startsWith("image/")) {
          const file = item.getAsFile();
          if (file) {
            loadFile(file);
            break;
          }
        }
      }
    });

    bindSeg(els.viewMode, "view", (value) => {
      state.view = value;
      render();
    });
    bindSeg(els.fitMode, "fit", (value) => {
      state.fit = value;
      mappedCache = null;
      if (state.image) render();
    });
    bindSeg(els.gridMode, "grid", (value) => {
      state.grid = Number(value);
      if (state.image) render();
    });

    els.guidesToggle.addEventListener("change", () => {
      state.guides = els.guidesToggle.checked;
      if (state.image) render();
    });

    els.exportBtn.addEventListener("click", () => {
      if (!state.image) return;
      els.canvas.toBlob((blob) => {
        if (!blob) return;
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = `profile-reference-${state.grid}x${state.grid}.png`;
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(link.href), 4000);
      }, "image/png");
    });

    els.resetBtn.addEventListener("click", () => {
      state.image = null;
      mappedCache = null;
      mappedByFit = new Map();
      colorCache = new Map();
      els.canvasWrap.hidden = true;
      els.actions.hidden = true;
      els.dropZone.hidden = false;
      els.fileInput.value = "";
      els.paletteUsage.innerHTML = '<p class="field-note">上传图片后，这里会列出需要用到哪些颜色、各占多少面积。</p>';
      els.statusHint.textContent = "还没有图片。上传后会按游戏调色板量化，并叠加网格参考。";
    });

    els.resetSettings.addEventListener("click", () => {
      state.fit = "cover";
      state.grid = 6;
      state.guides = true;
      state.view = "mapped";
      els.fitMode.querySelectorAll("button").forEach((b) => b.classList.toggle("is-on", b.dataset.fit === "cover"));
      els.gridMode.querySelectorAll("button").forEach((b) => b.classList.toggle("is-on", b.dataset.grid === "6"));
      els.viewMode.querySelectorAll("button").forEach((b) => b.classList.toggle("is-on", b.dataset.view === "mapped"));
      els.guidesToggle.checked = true;
      mappedCache = null;
      mappedByFit = new Map();
      if (state.image) render();
    });
  }

  function main() {
    els.canvasSize.textContent = `${CANVAS_W}×${CANVAS_H}`;
    bindEvents();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }
})();
