#!/usr/bin/env python3
"""生成 33 色调色板 → 角色 / 组合名称的对照表。

输入（来自 Sekai-World 国服 master DB）
  data/gameCharacters.json      角色中英文名
  data/gameCharacterUnits.json  每个角色在各组合下的代表色 colorCode
  data/unitProfiles.json        5 个组合 + 虚拟歌手的组合色
  data/profile-spec.json        名片编辑器实测的 33 色（顺序即游戏内排列）

输出
  data/palette-names.json       页面内嵌用
  assets/palette-names.md       给人核对的对照表

结论：游戏内 33 格 = 20 位原创角色代表色 + 6 位虚拟歌手代表色
      + 5 个组合代表色 + 纯白 + 近黑(#444466)，与官方色值一一对应。
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
ASSETS = ROOT / "assets"

UNIT_CN = {
    "light_sound": "Leo/need",
    "idol": "MORE MORE JUMP！",
    "street": "Vivid BAD SQUAD",
    "theme_park": "Wonderlands×Showtime",
    "school_refusal": "25点，Nightcord见。",
    "piapro": "虚拟歌手",
}
UNIT_SHORT = {
    "light_sound": "Leo/need",
    "idol": "MMJ！",
    "street": "VBS",
    "theme_park": "W×S",
    "school_refusal": "25时",
    "piapro": "VS",
}


def main() -> None:
    chars = {c["id"]: c for c in json.loads((DATA / "gameCharacters.json").read_text(encoding="utf-8"))}
    cunits = json.loads((DATA / "gameCharacterUnits.json").read_text(encoding="utf-8"))
    units = json.loads((DATA / "unitProfiles.json").read_text(encoding="utf-8"))
    spec = json.loads((DATA / "profile-spec.json").read_text(encoding="utf-8"))

    palette = [c.upper() for c in spec["palette"]["colors"]]

    # 角色代表色：每个角色取其自身组合下的 colorCode
    char_color: dict[int, str] = {}
    for cu in cunits:
        char_color.setdefault(cu["gameCharacterId"], cu["colorCode"].upper())

    by_hex: dict[str, dict] = {}
    by_hex["#FFFFFF"] = {
        "label": "白", "sub": "White", "source": "neutral",
        "note": "纯白，同时也是「虚拟歌手」组合色",
    }
    by_hex["#444466"] = {
        "label": "近黑", "sub": "Dark navy", "source": "neutral",
        "note": "唯一的深色，接近黑但不是纯黑",
    }

    # 6 位虚拟歌手
    for cid in (21, 22, 23, 24, 25, 26):
        c = chars.get(cid, {})
        cn = f"{c.get('firstName', '')}{c.get('givenName', '')}" or c.get("givenNameEnglish", "")
        en = c.get("givenNameEnglish", "")
        by_hex[char_color[cid]] = {
            "label": cn, "sub": en.capitalize(),
            "source": "virtual_singer", "characterId": cid,
        }

    # 5 个组合
    for unit in units:
        if unit["unit"] == "piapro":
            continue
        by_hex[unit["colorCode"].upper()] = {
            "label": UNIT_CN[unit["unit"]], "sub": UNIT_SHORT[unit["unit"]],
            "source": "unit", "unit": unit["unit"],
        }

    # 20 位原创角色
    for cid in range(1, 21):
        c = chars[cid]
        by_hex[char_color[cid]] = {
            "label": f"{c['firstName']}{c['givenName']}",
            "sub": c["givenNameEnglish"].capitalize(),
            "source": "character", "characterId": cid,
            "unit": c.get("unit", ""), "unitShort": UNIT_SHORT.get(c.get("unit", ""), ""),
        }

    ordered = []
    missing = []
    for idx, hex_value in enumerate(palette):
        entry = by_hex.get(hex_value)
        if not entry:
            missing.append(hex_value)
            entry = {"label": hex_value, "sub": "", "source": "unknown"}
        ordered.append({"idx": idx, "hex": hex_value, **entry})

    out = {
        "source": "sekai-master-db-cn-diff: gameCharacters / gameCharacterUnits / unitProfiles",
        "note": "33 色 = 20 位原创角色代表色 + 6 位虚拟歌手代表色 + 5 个组合代表色 + 纯白 + 近黑",
        "colors": ordered,
    }
    (DATA / "palette-names.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")

    # 人看的对照表
    rows = []
    for e in ordered:
        source = {"neutral": "特殊", "virtual_singer": "虚拟歌手", "unit": "组合",
                  "character": "角色", "unknown": "未匹配"}.get(e["source"], e["source"])
        rows.append(f"| {e['idx'] + 1} | `{e['hex']}` | **{e['label']}** | {e['sub']} | {source} | {e.get('note', '')} |")
    md = [
        "# 33 色调色板 · 名称对照表",
        "",
        "数据来源：`sekai-master-db-cn-diff` 的 `gameCharacters.json` / `gameCharacterUnits.json` / `unitProfiles.json`。",
        "",
        "构成：**20 位原创角色代表色 + 6 位虚拟歌手代表色 + 5 个组合代表色 + 纯白 + 近黑 = 33**。",
        "",
        "> 33 个格子与官方色值全部一一对应（截图取色已按 17 的倍数还原）。",
        "",
        "| # | 色值 | 名称 | 英文 | 来源 | 备注 |",
        "| --- | --- | --- | --- | --- | --- |",
    ] + rows
    (ASSETS / "palette-names.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print(f"写出 data/palette-names.json（{len(ordered)} 色）")
    print(f"写出 assets/palette-names.md")
    if missing:
        print("⚠️ 未匹配到官方色值的格子：", missing)
    else:
        print("全部 33 格均匹配到官方色值")


if __name__ == "__main__":
    main()
